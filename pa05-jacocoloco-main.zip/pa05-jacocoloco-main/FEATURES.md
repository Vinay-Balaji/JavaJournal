## Section 1: Requirements
- Week View
- Event and Task Creation
- Commitment Warnings
- Persistence

## Section 2: Headlining Features
- Task Queue
- Categories

## Section 3: Power Ups
- Quotes & Notes
- Mini Viewer
- Takesie-backsies

## Section 4: Quality of Life
- Auto #tags 
- Mind Changes

## Section 5: Extra Credit
- Deployable Application
- Visual Flourish (Changed fonts, colors, border colors, background colors for the Week View)
- Weekly Starters(Steps for creating template: 1. Create new file 2. 
Set Max Tasks & Events 3. Creates Event or Task with desired category 4.Delete all events and tasks till empty 5. Save
Template with desired name.)
