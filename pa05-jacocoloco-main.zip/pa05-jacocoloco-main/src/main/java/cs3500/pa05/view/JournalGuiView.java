package cs3500.pa05.view;

import javafx.scene.Scene;

/**
 * View for the Journal Conroller
 */
public interface JournalGuiView {
  /**
   * Loads a scene from a DataModelAdapter GUI layout.
   *
   * @return the layout
   */
  Scene load() throws IllegalStateException;
}
