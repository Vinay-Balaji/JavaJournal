package cs3500.pa05.model;

/**
 * Represents the days of the week
 */
public enum Day {
  SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"),
  THURSDAY("Thursday"), FRIDAY("Friday"), SATURDAY("Saturday");

  /**
   * Constructs a day with the specified string representation.
   *
   * @param s - the string representation of the day
   */
  Day(String s) {
    dayStr = s;
  }

  private String dayStr;

  /**
   * Returns the string representation of the day.
   *
   * @return - the string representation of the day
   */
  @Override
  public String toString() {
    return dayStr;
  }
}
