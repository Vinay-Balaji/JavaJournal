package cs3500.pa05.model.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * Represents a JSON object for serializing/deserializing a journal.
 *
 * @param taskList - the list of task items
 * @param eventList - the list of event items
 * @param categoryList - the list of categories
 * @param maxTasksPerDay - the maximum number of tasks per day
 * @param maxEventsPerDay - the maximum number of events per day
 * @param notes - the journal notes
 */
public record JournalJson(
    @JsonProperty("taskList")List<TaskJson> taskList,
    @JsonProperty("eventList") List<EventJson> eventList,
    @JsonProperty("categoryList") List<CategoryJson> categoryList,
    @JsonProperty("maxTasksPerDay") int maxTasksPerDay,
    @JsonProperty("maxEventsPerDay") int maxEventsPerDay,
    @JsonProperty("notes") String notes
) {
}


