package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa05.model.Category;
import org.junit.jupiter.api.Test;

class CategoryTest {

  @Test
  void getName() {
    Category category = new Category("name");
    assertEquals("name", category.getName());
  }
}