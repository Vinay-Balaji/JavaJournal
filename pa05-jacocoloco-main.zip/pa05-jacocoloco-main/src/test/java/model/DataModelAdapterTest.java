package model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.DataModelAdapter;
import cs3500.pa05.model.Event;
import cs3500.pa05.model.Task;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DataModelAdapterTest {
  private DataModelAdapter adapter;
  private DataModel dataModel;

  @BeforeEach
  void setUp() {
    adapter = new DataModelAdapter();
    dataModel = new DataModel();
  }

  @Test
  void testSetupAll() {
    adapter.setupAll(dataModel);

    assertEquals(dataModel.getNotes(), adapter.getNotes());
    assertEquals(dataModel.getMaxTasksPerDay(), adapter.getTaskLimitPerDay());
    assertEquals(dataModel.getMaxEventsPerDay(), adapter.getEventLimitPerDay());

    // If the tasks and events are supposed to be the same
    assertEquals(dataModel.getAllItems().stream().filter(item -> item instanceof Task).count(),
        adapter.getTasks().size());
    assertEquals(dataModel.getAllItems().stream().filter(item -> item instanceof Event).count(),
        adapter.getEvents().size());

    // If the categories are supposed to be the same
    assertEquals(dataModel.getCategoryList(), adapter.getCategories());
  }

  @Test
  void testTasksSetup() {
    dataModel.init();
    Event event = new Event("a", "Tuesday", "a",
        "a", "a", "a");
    dataModel.addItem(event);
    Task task = new Task("a", "Monday", "a", "a");
    dataModel.addItem(task);
    adapter.setupAll(dataModel);
    assertTrue(adapter.getTasks().contains(task));
    assertTrue(adapter.getEvents().contains(event));
  }
}