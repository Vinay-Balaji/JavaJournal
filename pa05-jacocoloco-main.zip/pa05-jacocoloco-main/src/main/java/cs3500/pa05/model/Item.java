package cs3500.pa05.model;

import javafx.beans.value.ObservableValue;

/**
 * Represents an item in a journal, such as a task or an event.
 */
public interface Item {
  /**
   * Returns the title of the item.
   *
   * @return - the title of the item
   */
  String getTitle();

  /**
   * Returns the day of the week associated with the item.
   *
   * @return - the day of the week associated with the item
   */
  Day getDayOfWeek();

  /**
   * Returns the observable value representing the title of the item.
   *
   * @return - the observable value representing the title of the item
   */
  ObservableValue<String> titleProperty();

}
