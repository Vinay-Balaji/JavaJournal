package model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import cs3500.pa05.model.Day;
import cs3500.pa05.model.Event;
import cs3500.pa05.model.Task;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class TaskTest {

  Task task;

  @BeforeEach
  void setup() {
    task = new Task("title", "MONDAY", "description", "CATEGORY", true);
  }

  @Test
  void setTitle() {
    assertEquals("title", task.getTitle());
    task.setTitle("newTitle");
    assertEquals("newTitle", task.getTitle());
  }

  @Test
  void setCategory() {
    assertEquals("CATEGORY", task.getCategory());
    task.setCategory("category");
    assertEquals("category", task.getCategory());
  }

  @Test
  void getTitle() {
    assertEquals("title", task.getTitle());
  }

  @Test
  void titleProperty() {
    assertEquals("ObjectProperty [value: title]", task.titleProperty().toString());
  }

  @Test
  void getDescription() {
    assertEquals("description", task.getDescription());
  }

  @Test
  void getDayOfWeek() {
    assertEquals(Day.MONDAY, task.getDayOfWeek());
  }

  @Test
  void isComplete() {
    assertEquals(true, task.isComplete());
  }

  @Test
  void completeProperty() {
    assertEquals(true, task.isComplete());
    assertEquals("BooleanProperty [value: true]", task.completeProperty().toString());
  }

  @Test
  void getCategory() {
    assertEquals("CATEGORY", task.getCategory());
  }

  // Test to string
  @Test
  void testToString() {
    assertEquals("Task: title", task.toString());
  }

  @Test
  void titleException() {
    assertThrows(IllegalArgumentException.class, () ->
        new Task(null, "MONDAY", "description", "category", true));
    assertThrows(IllegalArgumentException.class, () ->
        new Task("", "MONDAY", "description", "category", true));
    assertThrows(IllegalArgumentException.class, () ->
        new Task(null, "MONDAY", "description", "category"));
    assertThrows(IllegalArgumentException.class, () ->
        new Task("", "MONDAY", "description", "category"));
  }

  @Test
  void dayOfWeekException() {
    assertThrows(IllegalArgumentException.class, () ->
        new Task("title", "", "description", "category", true));
    assertThrows(IllegalArgumentException.class, () ->
        new Task("title", null, "description", "category", true));
    assertThrows(IllegalArgumentException.class, () ->
        new Task("title", "", "description", "category"));
    assertThrows(IllegalArgumentException.class, () ->
        new Task("title", null, "description", "category"));
  }

  @Test
  void categoryException() {
    Task nullCategory = new Task("title", "MONDAY", "description", "", true);
    Task emptyCategory = new Task("title", "MONDAY", "description", null, true);

    assertEquals("No category", nullCategory.getCategory());
    assertEquals("No category", emptyCategory.getCategory());

    Task nullCategoryNon = new Task("title", "MONDAY", "description", "");
    Task emptyCategoryNon = new Task("title", "MONDAY", "description", null);

    assertEquals("No category", nullCategoryNon.getCategory());
    assertEquals("No category", emptyCategoryNon.getCategory());

    Task regularNon = new Task("title", "MONDAY", "description", "hi");

    assertEquals("hi", regularNon.getCategory());
  }


}