package cs3500.pa05.model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;

/**
 * Represents a task item
 */
public class Task implements Item {
  private ObjectProperty<String> title;
  private String description;
  private Day dayOfWeek;
  private BooleanProperty isComplete = new SimpleBooleanProperty();
  private String category;

  /**
   * Constructs a task with the given title, day of the week, description, and category.
   *
   * @param title - the title of the task
   * @param dayOfWeek - the day of the week associated with the task
   * @param description - the description of the task
   * @param category - the category of the task
   */
  public Task(String title, String dayOfWeek, String description, String category) {
    if (title == null || title.isBlank()) {
      throw new IllegalArgumentException("Task must have a title");
    }
    this.title = new SimpleObjectProperty<>(title);
    if (dayOfWeek == null || dayOfWeek.isBlank()) {
      throw new IllegalArgumentException("Task must have an associated day");
    }
    this.dayOfWeek = Day.valueOf(dayOfWeek.toUpperCase());
    this.isComplete.set(false);
    this.description = description;
    if (category == null || category.isBlank()) {
      this.category = "No category";
    } else {
      this.category = category;
    }
  }

  /**
   * Constructs a task with the given title, day of the week, description, category, and
   * completion status.
   *
   * @param title - the title of the task
   * @param dayOfWeek - the day of the week associated with the task
   * @param description - the description of the task
   * @param category - the category of the task
   * @param completed - the completion status of the task
   */
  public Task(String title, String dayOfWeek, String description, String category,
              boolean completed) {
    if (title == null || title.isBlank()) {
      throw new IllegalArgumentException("Task must have a title");
    }
    this.title = new SimpleObjectProperty<>(title);
    if (dayOfWeek == null || dayOfWeek.isBlank()) {
      throw new IllegalArgumentException("Task must have an associated day");
    }
    this.dayOfWeek = Day.valueOf(dayOfWeek.toUpperCase());
    this.isComplete.set(false);
    this.description = description;
    if (category == null || category.isBlank()) {
      this.category = "No category";
    } else {
      this.category = category;
    }
    isComplete.set(completed);
  }

  /**
   * Sets the title of the task
   *
   * @param title - the title of the task
   */
  public void setTitle(String title) {
    this.title.setValue(title);
  }

  /**
   * Sets the category of the task
   *
   * @param category - the category
   */
  public void setCategory(String category) {
    this.category = category;
  }

  /**
   * Returns the title of the task
   *
   * @return - the title of the task
   */
  public String getTitle() {
    return title.getValue();
  }

  /**
   * Returns the property representing the title of the task
   *
   * @return - the property representing the title of the task
   */
  @Override
  public ObjectProperty<String> titleProperty() {
    return title;
  }

  /**
   * Returns the description of the task
   *
   * @return - the description of the task
   */
  public String getDescription() {
    return description;
  }

  /**
   * Returns the day of the week associated with the task.
   *
   * @return - the day of the week associated with the task.
   */
  @Override
  public Day getDayOfWeek() {
    return dayOfWeek;
  }

  /**
   * Returns the completion status of the task.
   *
   * @return - the completion status of the task.
   */
  public boolean isComplete() {
    return isComplete.getValue();
  }

  /**
   * Returns the observable value representing the completion status of the task.
   *
   * @return - the observable value representing the completion status of the task
   */
  public ObservableValue<Boolean> completeProperty() {
    return isComplete;
  }

  /**
   * Returns the category of the task.
   *
   * @return - the category of the task
   */
  public String getCategory() {
    return category;
  }

  /**
   * Returns a string representation of the task.
   *
   * @return - a string representation of the task
   */
  @Override
  public String toString() {
    return "Task: " + title.getValue();
  }

}