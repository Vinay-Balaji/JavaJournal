package cs3500.pa05.model.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import cs3500.pa05.model.Day;

/**
 * Represents a JSON object for serializing/deserializing a task.
 *
 * @param title - the title of the task
 * @param description - the description of the task
 * @param dayOfWeek - the day of the week associated with the task
 * @param isComplete - the completion status of the task
 * @param category - the category of the task
 */
public record TaskJson(
    @JsonProperty("title") String title,
    @JsonProperty("description") String description,
    @JsonProperty("dayOfWeek") Day dayOfWeek,
    @JsonProperty("isComplete") boolean isComplete,
    @JsonProperty("category") String category
) {
}

