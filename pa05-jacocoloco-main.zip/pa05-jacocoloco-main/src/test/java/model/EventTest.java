package model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import cs3500.pa05.model.Day;
import cs3500.pa05.model.Event;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class EventTest {

  Event event;

  @BeforeEach
  void setUp() {

    event = new Event("title", "MONDAY",
        "9:00", "3hr", "description", "CATEGORY");
  }

  @Test
  void setTitle() {
    assertEquals("title", event.getTitle());
    event.setTitle("newTitle");
    assertEquals("newTitle", event.getTitle());
  }

  @Test
  void setCategory() {
    assertEquals("CATEGORY", event.getCategory());
    event.setCategory("newCategory");
    assertEquals("newCategory", event.getCategory());
  }

  @Test
  void getTitle() {
    assertEquals("title", event.getTitle());
  }

  @Test
  void titleProperty() {
    assertEquals("ObjectProperty [value: title]", event.titleProperty().toString());
  }

  @Test
  void getDescription() {
    assertEquals("description", event.getDescription());
  }

  @Test
  void getDayOfWeek() {
    assertEquals(Day.MONDAY, event.getDayOfWeek());
  }

  @Test
  void getStartTime() {
    assertEquals("9:00", event.getStartTime());
  }

  @Test
  void getDuration() {
    assertEquals("3hr", event.getDuration());
  }

  @Test
  void getCategory() {
    assertEquals("CATEGORY", event.getCategory());
  }

  @Test
  void testToString() {
    assertEquals("Event: title", event.toString());
  }

  @Test
  void titleException() {
    assertThrows(IllegalArgumentException.class, () ->
        new Event(null, "MONDAY", "9:00",
            "3hr", "description", "category"));
    assertThrows(IllegalArgumentException.class, () ->
        new Event("", "MONDAY", "9:00",
            "3hr", "description", "category"));
  }

  @Test
  void dayOfWeekException() {
    assertThrows(IllegalArgumentException.class, () ->
        new Event("title", null, "9:00",
            "3hr", "description", "category"));
    assertThrows(IllegalArgumentException.class, () ->
        new Event("title", "", "9:00",
            "3hr", "description", "category"));
  }

  @Test
  void startTimeException() {
    assertThrows(IllegalArgumentException.class, () ->
        new Event("title", "MONDAY", null,
            "3hr", "description", "category"));
    assertThrows(IllegalArgumentException.class, () ->
        new Event("title", "MONDAY", "",
            "3hr", "description", "category"));
  }

  @Test
  void durationException() {
    assertThrows(IllegalArgumentException.class, () ->
        new Event("title", "MONDAY", "9:00",
            null, "description", "category"));
    assertThrows(IllegalArgumentException.class, () ->
        new Event("title", "MONDAY", "9:00",
            "", "description", "category"));
  }

  @Test
  void categoryException() {
    Event nullCategory = new Event("title", "MONDAY", "9:00",
            "3hr", "description", null);
    Event emptyCategory = new Event("title", "MONDAY", "9:00",
        "3hr", "description", "");

    assertEquals("No category", nullCategory.getCategory());
    assertEquals("No category", emptyCategory.getCategory());
  }
}