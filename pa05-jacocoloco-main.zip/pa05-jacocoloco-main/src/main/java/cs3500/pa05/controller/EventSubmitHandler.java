package cs3500.pa05.controller;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 * The EventSubmitHandler class is responsible for handling events related to submitting an event.
 */
public class EventSubmitHandler implements EventHandler {

  TextField eventPromptTitle;

  EventSubmitHandler(TextField eventPromptTitle) {
    this.eventPromptTitle = eventPromptTitle;
  }

  @Override
  public void handle(Event event) {
    System.out.println(eventPromptTitle.getText());
  }
}
