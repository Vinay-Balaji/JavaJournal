package cs3500.pa05.model;

//import java.util.*;

import java.util.ArrayList;
import java.util.List;

/**
 * The DataModelAdapter class is responsible for adapting a DataModel to the required format
 */
public class DataModelAdapter {

  private List<Task> tasks;
  private List<Event> events;
  private List<String> categories;
  private int taskLimitPerDay;
  private int eventLimitPerDay;
  private String notes;

  /**
   * Constructs a DataModelAdapter object with empty task, event, and category lists.
   */
  public DataModelAdapter() {
    this.tasks = new ArrayList<>();
    this.events = new ArrayList<>();
    this.categories = new ArrayList<>();
  }

  /**
   * Sets up the DataModelAdapter by populating the adapter's data structures with the
   * relevant data from the provided DataModel.
   *
   * @param dataModel - The DataModel to extract data from.
   */
  public void setupAll(DataModel dataModel) {
    this.tasksSetup(dataModel);
    this.eventsSetup(dataModel);
    this.categoriesSetup(dataModel);
    this.maxSetup(dataModel);
    this.notes = dataModel.getNotes();
  }

  private void tasksSetup(DataModel dataModel) {
    for (Item item : dataModel.getAllItems()) {
      if (item instanceof Task) {
        this.tasks.add((Task) item);
      }
    }
  }

  private void eventsSetup(DataModel dataModel) {
    for (Item item : dataModel.getAllItems()) {
      if (item instanceof Event) {
        this.events.add((Event) item);
      }
    }
  }

  /**
   * Populates the categories list in the adapter with the categories from the DataModel.
   *
   * @param dataModel - The DataModel to extract categories from.
   */
  public void categoriesSetup(DataModel dataModel) {
    this.categories = dataModel.getCategoryList();
  }

  /**
   * Sets up the maximum task and event limits per day in the adapter using the values
   * from the DataModel.
   *
   * @param dataModel - The DataModel to extract limits from.
   */
  public void maxSetup(DataModel dataModel) {
    this.eventLimitPerDay = dataModel.getMaxEventsPerDay();
    this.taskLimitPerDay = dataModel.getMaxTasksPerDay();
  }

  /**
   * Returns the list of tasks in the adapter.
   *
   * @return - The list of tasks.
   */
  public List<Task> getTasks() {
    return this.tasks;
  }

  /**
   * Returns the list of events in the adapter.
   *
   * @return - The list of events.
   */
  public List<Event> getEvents() {
    return this.events;
  }

  /**
   * Returns the list of categories in the adapter.
   *
   * @return - The list of categories.
   */
  public List<String> getCategories() {
    return this.categories;
  }

  /**
   * Returns the notes stored in the adapter.
   *
   * @return - The notes.
   */
  public String getNotes() {
    return notes;
  }

  /**
   * Returns the task limit per day stored in the adapter.
   *
   * @return - The task limit per day.
   */
  public int getTaskLimitPerDay() {
    return this.taskLimitPerDay;
  }

  /**
   * Returns the event limit per day stored in the adapter.
   *
   * @return - The event limit per day.
   */
  public int getEventLimitPerDay() {
    return this.eventLimitPerDay;
  }
}