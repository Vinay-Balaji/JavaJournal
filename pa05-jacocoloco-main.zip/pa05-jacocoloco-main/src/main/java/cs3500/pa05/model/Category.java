package cs3500.pa05.model;

/**
 * Represents a category for tasks or events.
 */
public class Category {
  private String name;

  /**
   * Constructs a category with the given name.
   *
   * @param name - the name of the category
   */
  public Category(String name) {
    this.name = name;
  }

  /**
   * Returns the name of the category.
   *
   * @return - the name of the category
   */
  public String getName() {
    return this.name;
  }
}
