package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.Task;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

/**
 * The EditTaskController class is responsible for controlling the task editing popup in the
 * journal application. It handles user interactions and manages the editing and submission of
 * tasks.
 */
public class EditTaskController {

  private final Popup popup;
  private final String resourcePath;
  private final DataModel model;

  @FXML
  private Button taskEditButton;

  @FXML
  private TextField taskEditTitle;

  @FXML
  private TextArea taskEditDescription;

  @FXML
  private ChoiceBox<String> taskEditDay;

  @FXML
  private ComboBox<String> taskEditCategory;

  @FXML private Label taskEditError;

  @FXML private CheckBox taskEditComplete;

  /**
   *  Constructs a new EditTaskController with the specified data model, stage, popup, and resource
   *  path.
   *
   * @param m - The data model.
   * @param p - The popup to be controlled.
   * @param path - The resource path to the FXML file for the task editing popup.
   */
  public EditTaskController(DataModel m, Popup p, String path) {
    popup = p;
    resourcePath = path;
    model = m;
  }

  /**
   * Sets up the task editing popup by loading the FXML file, configuring the UI components,
   * and registering event handlers.
   */
  public void setup() {
    FXMLLoader loader = new FXMLLoader();
    loader.setLocation(getClass().getClassLoader().getResource(this.resourcePath));
    loader.setController(this);
    try {
      Parent parent = ((Scene) loader.load()).getRoot();
      popup.getContent().add(parent);
      popup.setOpacity(1.0);
    } catch (IOException e) {
      throw new RuntimeException("Could not load resource");
    }

    this.taskEditButton.setOnAction(e -> handleSubmit());
    this.taskEditDay.getItems()
        .addAll("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    taskEditCategory.setItems(model.getCategoryList());
    taskEditCategory.setValue("No category");
  }

  /**
   * Initializes the fields of the task editing popup with the values of the currently selected
   * task.
   */
  public void initFields() {
    Task task = (Task) this.model.getCurrentItem();

    taskEditDay.setValue(task.getDayOfWeek().toString());
    taskEditTitle.setText(task.getTitle());
    taskEditComplete.setSelected(task.isComplete());
    taskEditDescription.setText(task.getDescription());
    taskEditCategory.setValue(task.getCategory());
  }

  /**
   * Handles the event triggered by the task edit button.
   */
  public void handleSubmit() {
    try {
      String title = taskEditTitle.getText();
      String category = taskEditCategory.getValue();


      Pattern pattern = Pattern.compile("#(\\S+?)(\\p{Z}|.$)");
      Matcher matcher = pattern.matcher(title);
      while (matcher.find()) {
        String tag = matcher.group().substring(1);
        model.addCategory(tag);
        category = tag;
        title = matcher.replaceFirst("");
      }

      Task toAdd = new Task(title,
          taskEditDay.getValue(),
          taskEditDescription.getText(),
          category,
          taskEditComplete.isSelected());

      this.model.replaceItem(this.model.getCurrentItem(), toAdd);

      // add category to list of category if new category
      model.addCategory(taskEditCategory.getValue());



      // Clear the form
      popup.hide();
      taskEditDay.setValue(null);
      taskEditTitle.clear();
      taskEditDescription.clear();
      taskEditCategory.setValue("No category");
      taskEditComplete.setSelected(false);
      taskEditError.setText("");


      // clear selected item in model
      model.currentItemProperty().set(null);
    } catch (IllegalArgumentException e) {
      taskEditError.setText(e.getMessage());
    }
  }
}
