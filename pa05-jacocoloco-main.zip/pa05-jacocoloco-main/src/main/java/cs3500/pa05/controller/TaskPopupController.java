package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.DataModelAdapter;
import cs3500.pa05.model.Day;
import cs3500.pa05.model.Item;
import cs3500.pa05.model.Task;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

/**
 * Controller for the task popup.
 */
public class TaskPopupController {

  @FXML
  private Button taskPromptSubmit;

  @FXML
  private TextField taskPromptTitle;

  @FXML
  private TextArea taskDescription;

  @FXML
  private ChoiceBox<String> taskPromptDay;

  @FXML
  private ComboBox<String> taskPromptCategory;

  @FXML private Label taskPromptError;


  private final DataModel model;
  private final Popup popup;
  private DataModelAdapter dataModelAdapter;
  private final String resourcePath;


  /**
   * Constructs a TaskPopupController with the specified parameters.
   *
   * @param m - the data model
   * @param p - the popup
   * @param path - the resource path
   */
  public TaskPopupController(DataModel m, Popup p, String path) {
    this.model = m;
    this.popup = p;
    this.resourcePath = path;
    this.setup();
  }

  /**
   * Sets up the task popup.
   */
  public void setup() {
    FXMLLoader loader = new FXMLLoader();
    loader.setLocation(getClass().getClassLoader().getResource(this.resourcePath));
    loader.setController(this);
    try {
      Parent parent = ((Scene) loader.load()).getRoot();
      popup.getContent().add(parent);
      popup.setOpacity(1.0);
    } catch (IOException e) {
      throw new RuntimeException("Could not load resource");
    }

    this.taskPromptSubmit.setOnAction(e -> handleSubmit());
    this.taskPromptDay.getItems()
        .addAll("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    taskPromptCategory.setItems(model.getCategoryList());
    taskPromptCategory.setValue("No category");
  }

  /**
   * Handles the submit button action.
   */
  public void handleSubmit() {
    try {
      String category = taskPromptCategory.getValue();
      String title = taskPromptTitle.getText();

      Pattern pattern = Pattern.compile("#(\\S+?)(\\p{Z}|.$)");
      Matcher matcher = pattern.matcher(title);
      while (matcher.find()) {
        String tag = matcher.group().substring(1);
        model.addCategory(tag);
        category = tag;
        title = matcher.replaceFirst("");
      }


      Task toAdd = new Task(title,
          this.taskPromptDay.getValue(),
          this.taskDescription.getText(),
          category);

      // Access day's item list and try to add the new task.
      ObservableList<Item> dayItems = model.getDayItemList(Day.valueOf(
          this.taskPromptDay.getValue().toUpperCase()));

      // Ensure the day's item list doesn't already contain max number of tasks
      long tasksForTheDay = dayItems.stream().filter(item -> item instanceof Task).count();
      if (tasksForTheDay >= model.getMaxTasksPerDay()) {
        throw new IllegalArgumentException("Task limit for the day has been reached");
      }

      // If it's valid to add, then add it to both the day's item list and the overall item list
      model.addItem(toAdd);

      // add category
      model.addCategory(this.taskPromptCategory.getValue());

      // Clear the form
      popup.hide();
      this.taskPromptTitle.clear();
      this.taskDescription.clear();
      this.taskPromptDay.setValue(null);
      this.taskPromptCategory.setValue("No category");
      this.taskPromptError.setText("");
      // clear selected item in model
      model.currentItemProperty().set(null);

    } catch (IllegalArgumentException e) {
      taskPromptError.setText(e.getMessage());
    }
  }
}