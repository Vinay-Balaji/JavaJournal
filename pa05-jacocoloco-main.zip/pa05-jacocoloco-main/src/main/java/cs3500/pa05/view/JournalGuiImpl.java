package cs3500.pa05.view;

import cs3500.pa05.controller.JournalControllerImpl;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

/**
 * Represents a graphical user interface (GUI) implementation for a journal application.
 */
public class JournalGuiImpl implements JournalGuiView {
  FXMLLoader loader;
  /**
   * Constructs a JournalGuiImpl with the specified controller.
   *
   * @param controller - journal controller
   */

  public JournalGuiImpl(JournalControllerImpl controller) {
    // initialization and location setting omitted for brevity
    loader = new FXMLLoader();
    this.loader.setLocation(getClass().getClassLoader().getResource("WeekView.fxml"));
    this.loader.setController(controller);
  }

  /**
   * Loads the scene
   *
   * @return - the loaded scene
   */
  @Override
  public Scene load() {
    try {
      return this.loader.load();
    } catch (IOException exc) {
      throw new IllegalStateException(exc);
    }
  }
}
