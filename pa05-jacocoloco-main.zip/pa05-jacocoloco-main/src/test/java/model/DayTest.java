package model;

//import static org.junit.jupiter.api.Assertions.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa05.model.Day;
import org.junit.jupiter.api.Test;

class DayTest {

  @Test
  void testToString() {
    assertEquals("Monday", Day.MONDAY.toString());
  }
}