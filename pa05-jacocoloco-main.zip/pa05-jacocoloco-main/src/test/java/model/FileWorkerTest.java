package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.Day;
import cs3500.pa05.model.Event;
import cs3500.pa05.model.FileWorker;
import cs3500.pa05.model.Task;
import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Scanner;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Test class for fileWorker utility class
 */
public class FileWorkerTest {
  DataModel dataModel;
  DataModel dataModel2;
  Event event1;
  Task task1;

  /**
   * Setup method to initialize variables
   */
  @BeforeEach
  public void setup() {
    dataModel = new DataModel();
    dataModel2 = new DataModel(FXCollections.observableArrayList(), new EnumMap<>(Day.class),
        new SimpleObjectProperty<>(null), FXCollections.observableArrayList(),
        5, 5, "AAAAAA");
    dataModel.init();
    event1 = new Event("a", "Tuesday", "a",
        "a", "a", "a");
    task1 = new Task("a", "Monday", "a", "a");
  }

  /**
   * Test method for save method
   *
   * @throws IOException if temp file creation fails
   */
  @Test
  public void testSaveToFile() throws IOException {
    dataModel.addItem(event1);
    dataModel.addItem(task1);
    dataModel.setMaxTasksPerDay(10);
    dataModel.addCategory("testcat");
    dataModel.setNotes("testnotes");
    File directory = new File("src/test/resources");
    File temp = File.createTempFile("temp", ".bujo", directory);
    FileWorker.handleSaveToFile(dataModel, temp.getAbsolutePath());
    Scanner s = new Scanner(temp);
    String actual = s.nextLine();
    String expected = "{\"taskList\":[{\"title\":\"a\",\"description\":\"a\",\"dayOfWeek\":\""
        + "MONDAY\",\"isComplete\":false,\"category\":\"a\"}],\"eventList\":[{\"title\":\"a\",\""
        + "description\":\"a\",\"dayOfWeek\":\"TUESDAY\",\"startTime\":\"a\",\"duration\":\"a\",\""
        + "category\":\"a\"}],\"categoryList\":[{\"category\":\"No category\"},{\"category\":\""
        +
        "No category\"},{\"category\":\"testcat\"}],\"maxTasksPerDay\":10,\"maxEventsPerDay\":5,\""
        + "notes\":\"testnotes\"}";
    assertEquals(expected, actual);
    temp.deleteOnExit();
  }


  /**
   * Method to test loading from file
   */
  @Test
  public void testLoadFromFile() {
    File test = new File("src/test/resources/testfile.bujo");
    dataModel = FileWorker.handleLoadFromFile(test.getAbsolutePath());
    assertEquals(3, dataModel.getCategoryList().size());
    assertEquals(2, dataModel.getAllItems().size());
    assertEquals(5, dataModel.getMaxEventsPerDay());
    assertEquals(10, dataModel.getMaxTasksPerDay());
  }


}
