package cs3500.pa05.model.json;

import com.fasterxml.jackson.annotation.JsonProperty;
import cs3500.pa05.model.Day;

/**
 * Represents a JSON object for serializing/deserializing an event.
 *
 * @param title - the title of the event
 * @param description - the description of the event
 * @param dayOfWeek - the day of the week associated with the event
 * @param startTime - the start time of the event
 * @param duration - the duration of the event
 * @param category - the category of the event
 */
public record EventJson(
    @JsonProperty("title") String title,
    @JsonProperty("description") String description,
    @JsonProperty("dayOfWeek") Day dayOfWeek,
    @JsonProperty("startTime") String startTime,
    @JsonProperty("duration") String duration,
    @JsonProperty("category") String category
) {

}
