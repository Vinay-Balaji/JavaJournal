package cs3500.pa05;

import cs3500.pa05.controller.JournalControllerImpl;
import cs3500.pa05.view.JournalGuiImpl;
import cs3500.pa05.view.JournalGuiView;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Driver for the application
 */
public class Driver extends Application {
  /**
   * Starts the GUI for the week view.
   *
   * @param stage the JavaFX stage to add elements to
   */

  @Override
  public void start(Stage stage) {
    JournalControllerImpl controller = new JournalControllerImpl(stage);
    JournalGuiView view = new JournalGuiImpl(controller);
    stage.setScene(view.load());
    stage.show();
  }

  /**
   * Entry point for the DataModelAdapter application
   *
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    launch();
  }
}
