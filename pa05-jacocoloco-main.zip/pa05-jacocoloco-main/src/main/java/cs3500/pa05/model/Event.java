package cs3500.pa05.model;

import java.time.Duration;
import java.time.LocalTime;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
/*

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
*/

/**
 * Represents an event item.
 */
public class Event implements Item {
  private ObjectProperty<String> title;
  private String description;
  private Day dayOfWeek;
  private String startTime;
  private String duration;
  private String category;

  /**
   * Constructs an event with the given title, day of the week, start time, duration, description,
   * and category.
   *
   * @param title - the title of the event
   * @param dayOfWeek - the day of the week associated with the event
   * @param startTime - the start time of the event
   * @param duration - the duration of the event
   * @param description - the description of the event
   * @param category - the category of the event
   */
  public Event(
      String title,
      String dayOfWeek,
      String startTime,
      String duration,
      String description,
      String category) {
    if (title == null || title.isBlank()) {
      throw new IllegalArgumentException("Event must have a title");
    }
    this.title = new SimpleObjectProperty<>(title);
    if (dayOfWeek == null || dayOfWeek.isBlank()) {
      throw new IllegalArgumentException("Event must have an associated day");
    }
    this.dayOfWeek = Day.valueOf(dayOfWeek.toUpperCase());
    if (startTime == null || startTime.isBlank()) {
      throw new IllegalArgumentException("Event must have a start time");
    }
    this.startTime = startTime;
    if (duration == null || duration.isBlank()) {
      throw new IllegalArgumentException("Event must have a duration");
    }
    this.duration = duration;
    this.description = description;
    if (category == null || category.isBlank()) {
      this.category = "No category";
    } else {
      this.category = category;
    }
  }

  /**
   * Sets the title of the event.
   *
   * @param title - the title of the event
   */
  public void setTitle(String title) {
    this.title.setValue(title);
  }

  /**
   * Sets the category for the event
   *
   * @param category - the category of the event
   */
  public void setCategory(String category) {
    this.category = category;
  }

  /**
   * Returns the title of the event.
   *
   * @return - the title of the event
   */
  public String getTitle() {
    return title.getValue();
  }

  /**
   * Returns the property representing the title of the event.
   *
   * @return - the property representing the title of the event
   */
  @Override
  public ObjectProperty<String> titleProperty() {
    return title;
  }

  /**
   * Returns the description of the event.
   *
   * @return - the description of the event
   */
  public String getDescription() {
    return description;
  }

  /**
   * Returns the day of the week associated with the event.
   *
   * @return - the day of the week associated with the event
   */
  @Override
  public Day getDayOfWeek() {
    return dayOfWeek;
  }

  /**
   * Returns the start time of the event.
   *
   * @return - the start time of the event
   */
  public String getStartTime() {
    return startTime;
  }

  /**
   * Returns the duration of the event.
   *
   * @return - the duration of the event
   */
  public String getDuration() {
    return duration;
  }

  /**
   * Returns the category of the event.
   *
   * @return - the category of the event
   */
  public String getCategory() {
    return category;
  }

  /**
   * Returns a string representation of the event.
   *
   * @return - a string representation of the event
   */
  @Override
  public String toString() {
    return "Event: " + title.getValue();
  }

}
