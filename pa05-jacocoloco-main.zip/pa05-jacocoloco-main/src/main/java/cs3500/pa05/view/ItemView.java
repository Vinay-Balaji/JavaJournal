package cs3500.pa05.view;

import cs3500.pa05.model.Item;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;

/**
 * Represents a view for displaying an item.
 */
public class ItemView extends VBox {
  Item item;

  /**
   * Constructs an ItemView with the given item.
   *
   * @param item - the item to be displayed
   */
  public ItemView(Item item) {
    this.item = item;
    this.initLabel();
    this.initButton();
  }

  /**
   * Initializes the label for displaying the item's title.
   */
  private void initLabel() {
    Label label = new Label(this.item.getTitle());
    this.getChildren().add(label);
  }

  /**
   * Initializes the button for handling actions related to the item.
   */
  private void initButton() {
    Button button = new Button("-");
    button.setPrefWidth(20);
    button.setPrefHeight(20);
    button.setOnAction(e -> handlePress());
    this.getChildren().add(button);
  }

  /**
   * Handles the button press event.
   */
  @FXML
  private void handlePress() {
    //this.controller.remove(this);
  }
}
