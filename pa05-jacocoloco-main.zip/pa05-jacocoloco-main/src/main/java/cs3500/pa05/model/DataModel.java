package cs3500.pa05.model;

import java.util.EnumMap;
import java.util.Map;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 * The DataModel class represents the data model of the journal application.
 * It manages the items, categories, and other properties of the journal.
 */
public class DataModel {
  private ObservableList<Item> itemList = FXCollections.observableArrayList();

  private Map<Day, ObservableList<Item>> itemListMap  = new EnumMap<>(Day.class);

  private ObjectProperty<Item> currentItem = new SimpleObjectProperty<>(null);
  
  private ObservableList<String> categoryList = FXCollections.observableArrayList();

  private int maxTasksPerDay;
  private int maxEventsPerDay;
  private String notes;

  /**
   * Constructs a new DataModel with default values.
   */
  public DataModel() {
    init();
  }

  /**
   * Constructs a new DataModel with the specified values.
   *
   * @param itemList - The list of items in the model.
   * @param itemListMap - The map of items grouped by day in the model.
   * @param currentItem - The currently selected item in the model.
   * @param categoryList - The list of categories in the model.
   * @param maxTasksPerDay - The maximum number of tasks per day in the model.
   * @param maxEventsPerDay - The maximum number of events per day in the model.
   * @param notes - The notes in the model.
   */
  public DataModel(ObservableList<Item> itemList, Map<Day, ObservableList<Item>> itemListMap,
                   ObjectProperty<Item> currentItem, ObservableList<String> categoryList,
                   int maxTasksPerDay, int maxEventsPerDay, String notes) {
    this.itemList = itemList;
    this.itemListMap = itemListMap;
    this.currentItem = currentItem;
    this.categoryList = categoryList;
    this.maxEventsPerDay = maxEventsPerDay;
    this.maxTasksPerDay = maxTasksPerDay;
    this.notes = notes;
  }

  /**
   * Initializes the DataModel by setting up default values and data structures.
   */
  public void init() {
    categoryList.add("No category");
    maxEventsPerDay = 5;
    maxTasksPerDay = 5;
    for (Day day : Day.values()) {
      itemListMap.put(day, FXCollections.observableArrayList());
    }
  }

  /**
   * Adds an item to the data model.
   *
   * @param item - The item to add.
   */
  public void addItem(Item item) {
    itemList.add(item);
    itemListMap.get(item.getDayOfWeek()).add(item);
  }

  /**
   * Removes an item from the data model.
   *
   * @param item - The item to remove
   */
  public void removeItem(Item item) {
    itemList.remove(item);
    itemListMap.get(item.getDayOfWeek()).remove(item);
  }

  /**
   * Replaces an old item with a new item in the data model.
   *
   * @param old - The old item to replace.
   * @param toAdd - The new item to add.
   */
  public void replaceItem(Item old, Item toAdd) {
    if (old != null && toAdd != null) {
      removeItem(old);
      addItem(toAdd);
    }
  }

  /**
   * Retrieves the list of items for a specific day in the data model.
   *
   * @param day - The day to retrieve the items for.
   * @return - The list of items for the specified day.
   */
  public ObservableList<Item> getDayItemList(Day day) {
    return itemListMap.get(day);
  }

  /**
   * Retrieves the list of all items in the data model.
   *
   * @return - The list of all items.
   */
  public ObservableList<Item> getAllItems() {
    return itemList;
  }

  /**
   * Retrieves the list of categories in the data model.
   *
   * @return - The list of categories.
   */
  public ObservableList<String> getCategoryList() {
    return categoryList;
  }

  /**
   * Adds a category to the data model.
   *
   * @param str - The category to add.
   */
  public void addCategory(String str) {
    // If the category does not exist, create and add it
    if (str != null && !categoryList.contains(str) && !str.isEmpty()) {
      categoryList.add(str);
    }
  }

  /**
   * Retrieves the property for the currently selected item in the data model.
   *
   * @return - The property for the currently selected item.
   */
  public final ObjectProperty<Item> currentItemProperty() {
    return currentItem;
  }

  /**
   * Retrieves the currently selected item in the data model.
   *
   * @return - The currently selected item.
   */
  public final Item getCurrentItem() {
    return currentItem.get();
  }

  /**
   * Sets the currently selected item in the data model.
   *
   * @param item - The item to set as the currently selected item.
   */
  public final void setCurrentItem(Item item) {
    currentItem.set(item);
  }

  /**
   * Retrieves the maximum number of tasks per day in the data model.
   *
   * @return - The maximum number of tasks per day.
   */
  public int getMaxTasksPerDay() {
    return maxTasksPerDay;
  }

  /**
   * Sets the maximum number of tasks per day in the data model.
   *
   * @param maxTasksPerDay - The maximum number of tasks per day.
   */
  public void setMaxTasksPerDay(int maxTasksPerDay) {
    this.maxTasksPerDay = maxTasksPerDay;
  }

  /**
   * Retrieves the maximum number of events per day in the data model.
   *
   * @return - The maximum number of events per day.
   */
  public int getMaxEventsPerDay() {
    return maxEventsPerDay;
  }

  /**
   * Sets the maximum number of events per day in the data model.
   *
   * @param maxEventsPerDay - The maximum number of events per day.
   */
  public void setMaxEventsPerDay(int maxEventsPerDay) {
    this.maxEventsPerDay = maxEventsPerDay;
  }

  /**
   * Retrieves the notes in the data model.
   *
   * @return - The notes.
   */
  public String getNotes() {
    return notes;
  }

  /**
   * Sets the notes in the data model.
   *
   * @param str - The notes to set.
   */
  public void setNotes(String str) {
    notes = str;
  }

  /**
   * Updates the data model with the values from another DataModel.
   *
   * @param model - The DataModel to update from.
   */
  public void updateModel(DataModel model) {
    itemList.clear();
    itemList.addAll(model.itemList);
    for (Day day : Day.values()) {
      itemListMap.get(day).clear();
      itemListMap.get(day).addAll(model.itemListMap.get(day));
    }
    currentItem.set(null);
    categoryList.clear();
    categoryList.addAll(model.categoryList);
    maxTasksPerDay = model.maxTasksPerDay;
    maxEventsPerDay = model.maxEventsPerDay;
    notes = model.notes;
  }
}