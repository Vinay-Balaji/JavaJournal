package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.Day;
import cs3500.pa05.model.Event;
import cs3500.pa05.model.Item;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

/**
 * The EventPopupController class is responsible for controlling the event popup in the journal
 * application.
 */
public class EventPopupController {

  private final Popup popup;
  private final String resourcePath;
  private final DataModel model;

  @FXML private Button eventPromptSubmit;

  @FXML private TextField eventPromptTitle;

  @FXML private TextField eventPromptStartTime;

  @FXML private TextField eventPromptDuration;

  @FXML private ComboBox<String> eventPromptCategory;

  @FXML private ChoiceBox<String> eventPromptDay;

  @FXML private TextArea eventDescription;

  @FXML private Label eventPromptError;

  /**
   * Constructs a new EventPopupController with the specified data model, stage, popup, and
   * resource path.
   *
   * @param m - The data model
   * @param p - The popup to be controlled.
   * @param path - The resource path to the FXML file for the event popup.
   */
  public EventPopupController(DataModel m, Popup p, String path) {
    popup = p;
    resourcePath = path;
    model = m;
  }

  /**
   * Sets up the event popup by loading the FXML file, configuring the UI components, and
   * registering event handlers.
   */
  public void setup() {
    FXMLLoader loader = new FXMLLoader();
    loader.setLocation(getClass().getClassLoader().getResource(resourcePath));
    loader.setController(this);
    try {
      Parent parent = ((Scene) loader.load()).getRoot();
      popup.getContent().add(parent);
      popup.setOpacity(1.0);
    } catch (IOException e) {
      throw new RuntimeException("Could not load resource");
    }

    eventPromptDay.getItems()
        .addAll("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    eventPromptCategory.setItems(model.getCategoryList());
    eventPromptCategory.setValue("No category");
    eventPromptSubmit.setOnAction(e -> handleSubmit());
  }

  /**
   * Handles the event triggered by the event submission button.
   */
  public void handleSubmit() {
    try {
      String title = eventPromptTitle.getText();
      String category = eventPromptCategory.getValue();

      // if tag detected, set category to tag, remove from title
      Pattern pattern = Pattern.compile("#(\\S+?)(\\p{Z}|.$)");
      Matcher matcher = pattern.matcher(title);
      if (matcher.find()) {
        String tag = matcher.group().substring(1);
        model.addCategory(tag);
        category = tag;
        title = matcher.replaceFirst("");
      }

      Event toAdd = new Event(title,
          eventPromptDay.getValue(),
          eventPromptStartTime.getText(),
          eventPromptDuration.getText(),
          eventDescription.getText(),
          category);

      // Access day's item list and try to add the new event.
      ObservableList<Item> dayItems = model.getDayItemList(Day.valueOf(
          eventPromptDay.getValue().toUpperCase()));

      // Ensure the day's item list doesn't already contain max number of events
      long eventsForTheDay = dayItems.stream().filter(item -> item instanceof Event).count();
      if (eventsForTheDay >= model.getMaxEventsPerDay()) {
        throw new IllegalArgumentException("Event limit for the day has been reached");
      }

      // If it's valid to add, then add it to the model
      model.addItem(toAdd);

      // add category if new
      model.addCategory(eventPromptCategory.getValue());

      // Clear the form
      popup.hide();
      eventPromptDay.setValue(null);
      eventPromptTitle.clear();
      eventPromptStartTime.clear();
      eventPromptDuration.clear();
      eventDescription.clear();
      eventPromptError.setText("");
      eventPromptCategory.setValue("No category");

      // clear selected item in model
      model.currentItemProperty().set(null);
    } catch (IllegalArgumentException e) {
      eventPromptError.setText(e.getMessage());
    }
  }

}