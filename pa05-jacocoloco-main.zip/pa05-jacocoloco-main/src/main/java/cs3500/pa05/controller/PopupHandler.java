package cs3500.pa05.controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Popup;
import javafx.stage.Stage;

/**
 * The PopupHandler class is responsible for handling events related to a popup in the Journal
 * application. It provides methods to show and hide the popup, as well as initializing fields in
 * associated controllers.
 */
class PopupHandler implements EventHandler<ActionEvent> {

  private final Stage stage;
  private final Popup popup;

  private EditEventController editEventController;

  private EditTaskController editTaskController;

  /**
   * Constructs a new PopupHandler with the specified stage and popup
   *
   * @param stage - The stage associated with the popup.
   * @param p - The popup to be handled.
   */
  public PopupHandler(Stage stage, Popup p) {
    this.stage = stage;
    this.popup = p;
  }

  /**
   * Constructs a new PopupHandler with the specified stage, popup, and EditEventController.
   *
   * @param stage - The stage associated with the popup.
   * @param p - The popup to be handled.
   * @param editEventController - The controller for editing events.
   */
  public PopupHandler(Stage stage, Popup p, EditEventController editEventController) {
    this.stage = stage;
    this.popup = p;
    this.editEventController = editEventController;
  }

  /**
   * Constructs a new PopupHandler with the specified stage, popup, and EditTaskController.
   *
   * @param stage - The stage associated with the popup.
   * @param p - The popup to be handled.
   * @param editTaskController - The controller for editing tasks.
   */
  public PopupHandler(Stage stage, Popup p, EditTaskController editTaskController) {
    this.stage = stage;
    this.popup = p;
    this.editTaskController = editTaskController;
  }

  /**
   * Handles the event when a popup shows up
   *
   * @param event the event which occurred
   */
  @Override
  public void handle(ActionEvent event) {
    System.out.println("Made it to popuphandler handle");
    if (popup.isShowing()) {
      popup.hide();
    } else {
      if (editEventController != null) {
        System.out.println("eventcontrollerinitfields");
        this.editEventController.initFields();
      } else if (editTaskController != null) {
        System.out.println("taskcontrollerinitfields");
        this.editTaskController.initFields();
      }
      System.out.println("Made it to popup show handle");
      popup.show(stage);
    }
  }
}

