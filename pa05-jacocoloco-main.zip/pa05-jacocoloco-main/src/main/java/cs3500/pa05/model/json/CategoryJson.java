package cs3500.pa05.model.json;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents a JSON object for serializing/deserializing a category.
 *
 * @param category - a category
 */
public record CategoryJson(
    @JsonProperty("category") String category
) {
}
