package model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.Day;
import cs3500.pa05.model.Event;
import cs3500.pa05.model.Task;
import java.util.EnumMap;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Class for testing of data model
 */
class DataModelTest {
  DataModel dataModel;
  DataModel dataModel2;
  Event event1;
  Task task1;

  /**
   * Setup method to initialize variables
   */
  @BeforeEach
  public void setup() {
    dataModel = new DataModel();
    dataModel2 = new DataModel(FXCollections.observableArrayList(), new EnumMap<>(Day.class),
        new SimpleObjectProperty<>(null), FXCollections.observableArrayList(),
        5, 5, "AAAAAA");
    dataModel.init();
    event1 = new Event("a", "Tuesday", "a",
        "a", "a", "a");
    task1 = new Task("a", "Monday", "a", "a");
  }

  /**
   * Test method for add item in data model
   */
  @Test
  public void testAddItem() {
    dataModel.addItem(event1);
    dataModel.addItem(task1);
    assertTrue(dataModel.getAllItems().contains(event1));
    assertTrue(dataModel.getAllItems().contains(task1));
    assertTrue(dataModel.getDayItemList(Day.MONDAY).contains(task1));
    assertTrue(dataModel.getDayItemList(Day.TUESDAY).contains(event1));
    assertFalse(dataModel.getDayItemList(Day.MONDAY).contains(event1));
  }

  /**
   * Test method for remove item in data model
   */
  @Test
  public void testRemoveItem() {
    dataModel.addItem(event1);
    dataModel.addItem(task1);
    assertTrue(dataModel.getAllItems().contains(event1));
    assertTrue(dataModel.getAllItems().contains(task1));
    assertTrue(dataModel.getDayItemList(Day.MONDAY).contains(task1));
    assertTrue(dataModel.getDayItemList(Day.TUESDAY).contains(event1));
    dataModel.removeItem(event1);
    assertFalse(dataModel.getAllItems().contains(event1));
    assertTrue(dataModel.getAllItems().contains(task1));
    assertTrue(dataModel.getDayItemList(Day.MONDAY).contains(task1));
    assertFalse(dataModel.getDayItemList(Day.TUESDAY).contains(event1));
  }

  /**
   * Test for replace method in data model
   */
  @Test
  public void testReplaceItem() {
    dataModel.addItem(task1);
    assertTrue(dataModel.getAllItems().contains(task1));
    assertTrue(dataModel.getDayItemList(Day.MONDAY).contains(task1));
    dataModel.replaceItem(task1, event1);
    assertTrue(dataModel.getAllItems().contains(event1));
    assertTrue(dataModel.getDayItemList(Day.TUESDAY).contains(event1));
    assertEquals(1, dataModel.getAllItems().size());
    dataModel.replaceItem(null, event1);
    dataModel.replaceItem(event1, null);
    assertTrue(dataModel.getAllItems().contains(event1));
    assertTrue(dataModel.getDayItemList(Day.TUESDAY).contains(event1));
    assertEquals(1, dataModel.getAllItems().size());
  }

  /**
   * Test method for add category method
   */
  @Test
  public void testAddCategory() {
    dataModel.addCategory("new");
    assertEquals(3, dataModel.getCategoryList().size());
    assertTrue(dataModel.getCategoryList().contains("new"));
    dataModel.addCategory(null);
    assertEquals(3, dataModel.getCategoryList().size());
    dataModel.addCategory("new");
    assertEquals(3, dataModel.getCategoryList().size());
    dataModel.addCategory("");
    assertEquals(3, dataModel.getCategoryList().size());
  }

  /**
   * Test current item property method
   */
  @Test
  public void testCurrentItem() {
    assertNull(dataModel.currentItemProperty().getValue());
    dataModel.setCurrentItem(event1);
    assertEquals(event1, dataModel.currentItemProperty().getValue());
    assertEquals(event1, dataModel.getCurrentItem());
  }

  /**
   * Test getting and setting max events/tasks per day
   */
  @Test
  public void testMax() {
    assertEquals(5, dataModel.getMaxEventsPerDay());
    assertEquals(5, dataModel.getMaxTasksPerDay());
    dataModel.setMaxEventsPerDay(10);
    dataModel.setMaxTasksPerDay(500);
    assertEquals(10, dataModel.getMaxEventsPerDay());
    assertEquals(500, dataModel.getMaxTasksPerDay());
  }

  /**
   * Test set notes method
   */
  @Test
  public void testSetNotes() {
    assertNull(dataModel.getNotes());
    dataModel.setNotes("aaaaa");
    assertEquals("aaaaa", dataModel.getNotes());
  }

  /**
   * Test updateModel method
   */
  @Test
  public void testUpdateModel() {
    dataModel2.init();
    dataModel.addItem(event1);
    dataModel.addItem(task1);
    dataModel.addCategory("test");
    dataModel.setNotes("test2");
    dataModel2.updateModel(dataModel);
    assertTrue(dataModel2.getCategoryList().contains("test"));
    assertEquals(5, dataModel2.getMaxTasksPerDay());
    assertEquals(5, dataModel2.getMaxEventsPerDay());
    assertTrue(dataModel2.getAllItems().contains(event1));
    assertTrue(dataModel2.getDayItemList(Day.MONDAY).contains(task1));
    assertEquals("test2", dataModel2.getNotes());
  }
}