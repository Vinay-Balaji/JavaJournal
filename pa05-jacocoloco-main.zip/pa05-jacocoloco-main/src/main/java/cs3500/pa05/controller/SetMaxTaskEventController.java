package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Popup;
import javafx.stage.Stage;

/**
 * Controller for setting the maximum number of tasks and events per day
 */
public class SetMaxTaskEventController {
  private final Popup popup;
  private final String resourcePath;
  private final DataModel model;


  @FXML
  private TextField maxTasks;

  @FXML
  private TextField maxEvents;

  @FXML
  private Label maxPromptError;

  @FXML
  private Button maxPromptSubmit;

  /**
   * Constructs a SetMaxTaskEventController with the specified parameters.
   *
   * @param model - the data model
   * @param p - the popup
   * @param path - the resource path
   */
  public SetMaxTaskEventController(DataModel model, Popup p, String path) {
    popup = p;
    resourcePath = path;
    this.model = model;
  }

  /**
   * Sets up the maximum task and event input form.
   */
  public void setup() {
    FXMLLoader loader = new FXMLLoader();
    loader.setLocation(getClass().getClassLoader().getResource(resourcePath));
    loader.setController(this);
    try {
      Parent parent = ((Scene) loader.load()).getRoot();
      popup.getContent().add(parent);
      popup.setOpacity(1.0);
    } catch (IOException e) {
      throw new RuntimeException("Could not load resource");
    }

    maxPromptSubmit.setOnAction(e -> handleSubmit());
  }


  /**
   * Handles the submit button action.
   */
  public void handleSubmit() {
    try {
      int maxTasksVal = Integer.parseInt(maxTasks.getText());
      int maxEventsVal = Integer.parseInt(maxEvents.getText());

      if (maxTasksVal <= 0 || maxEventsVal <= 0) {
        maxPromptError.setText("Input must be a number greater than 0");
        return;
      }

      model.setMaxTasksPerDay(maxTasksVal);
      model.setMaxEventsPerDay(maxEventsVal);

      maxPromptError.setText("");
      popup.hide();
      maxTasks.clear();
      maxEvents.clear();
    } catch (NumberFormatException e) {
      maxPromptError.setText("Input must be a number");
    }
  }


}
