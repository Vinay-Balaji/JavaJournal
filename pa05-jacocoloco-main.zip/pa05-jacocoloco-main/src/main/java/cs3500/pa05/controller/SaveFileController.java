package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.FileWorker;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

/**
 * Class representing controller for a save file controller
 */
public class SaveFileController {
  private final Popup popup;
  private final String resourcePath;
  private final DataModel model;

  @FXML
  private TextField savePromptInput;

  @FXML
  private Label savePromptError;

  @FXML
  private Button savePromptSubmit;

  /**
   * Constructor for this popup controller
   *
   * @param m injected data model
   * @param p popup javafx object
   * @param path path of fxml resource
   */
  public SaveFileController(DataModel m, Popup p, String path) {
    model = m;
    popup = p;
    resourcePath = path;
  }

  /**
   * Handles initial methods to be called upon setting up popup
   */
  public void setup() {
    FXMLLoader loader = new FXMLLoader();
    loader.setController(this);
    loader.setLocation(getClass().getClassLoader().getResource(resourcePath));
    try {
      Parent parent = ((Scene) loader.load()).getRoot();
      popup.getContent().add(parent);
      popup.setOpacity(1.0);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    savePromptSubmit.setOnAction(e -> handleSubmit());
  }

  /**
   * Handles action upon hitting submit button for popup
   */
  public void handleSubmit() {
    String filePath = savePromptInput.getText().trim();
    try {
      FileWorker.handleSaveToFile(model, filePath);
      savePromptError.setText("");
      popup.hide();
      savePromptInput.clear();
    } catch (IllegalArgumentException e) {
      savePromptError.setText(e.getMessage());
    }
  }

}

