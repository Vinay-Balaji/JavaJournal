package cs3500.pa05.model;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cs3500.pa05.model.json.CategoryJson;
import cs3500.pa05.model.json.EventJson;
import cs3500.pa05.model.json.JournalJson;
import cs3500.pa05.model.json.TaskJson;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * The FileWorker class provides methods for saving and loading a DataModel to/from a file.
 */
public class FileWorker {

  /**
   * Saves the DataModel to a bujo file in the JSON format.
   *
   * @param model - The DataModel to be saved.
   * @param destination string representing path to destination file
   */
  public static void handleSaveToFile(DataModel model, String destination) {
    DataModelAdapter dataModelAdapter = new DataModelAdapter();

    dataModelAdapter.setupAll(model);

    ArrayList<TaskJson> taskJsons = new ArrayList<>();
    for (Task task : dataModelAdapter.getTasks()) {
      taskJsons.add(
          new TaskJson(task.getTitle(), task.getDescription(), task.getDayOfWeek(),
              task.isComplete(), task.getCategory()));
    }

    ArrayList<EventJson> eventJsons = new ArrayList<>();
    for (cs3500.pa05.model.Event event : dataModelAdapter.getEvents()) {
      eventJsons.add(
          new EventJson(event.getTitle(), event.getDescription(), event.getDayOfWeek(),
              event.getStartTime(), event.getDuration(), event.getCategory()));
    }

    ArrayList<CategoryJson> categoryJsons = new ArrayList<>();
    for (String category : dataModelAdapter.getCategories()) {
      categoryJsons.add(new CategoryJson(category));
    }

    JournalJson journalJson =
        new JournalJson(taskJsons, eventJsons, categoryJsons, dataModelAdapter.getTaskLimitPerDay(),
            dataModelAdapter.getEventLimitPerDay(), dataModelAdapter.getNotes());

    ObjectMapper objectMapper = new ObjectMapper();
    System.out.println(journalJson.taskList());
    System.out.println(journalJson.eventList());
    System.out.println(journalJson.categoryList());
    System.out.println(journalJson.maxTasksPerDay());

    JsonNode jsonNode = objectMapper.convertValue(journalJson, JsonNode.class);

    try {
      objectMapper.writeValue(new File(destination), jsonNode);
    } catch (IOException e) {
      throw new IllegalArgumentException("Error writing to file", e);
    }
  }

  /**
   * Loads a DataModel from a file in the JSON format.
   *
   * @param path string representing file to load data from
   * @return - The loaded DataModel.
   */
  public static DataModel handleLoadFromFile(String path) {
    JournalJson newJournal;

    ObjectMapper objectMapper = new ObjectMapper();


    try {
      newJournal = objectMapper.readValue(new File(path), JournalJson.class);
    } catch (NullPointerException e) {
      throw new IllegalArgumentException("File at specified path does not exist");
    } catch (JsonParseException g) {
      throw new IllegalArgumentException("File could not be parsed as JSON");
    } catch (JsonMappingException h) {
      throw new IllegalArgumentException("File JSON structure does not match expected type");
    } catch (IOException f) {
      throw new IllegalArgumentException("File could not be opened");
    }


    List<Task> taskList = new ArrayList<>();
    for (TaskJson taskJson : newJournal.taskList()) {
      taskList.add(new Task(taskJson.title(), taskJson.dayOfWeek().toString(),
          taskJson.description(), taskJson.category()));
    }

    List<cs3500.pa05.model.Event> eventList = new ArrayList<>();
    for (EventJson eventJson : newJournal.eventList()) {
      eventList.add(new cs3500.pa05.model.Event(eventJson.title(),
          eventJson.dayOfWeek().toString(), eventJson.startTime(), eventJson.duration(),
          eventJson.description(), eventJson.category()));
    }

    List<Item> itemArrayList = new ArrayList<>();
    itemArrayList.addAll(taskList);
    itemArrayList.addAll(eventList);

    Map<Day, ObservableList<Item>> itemListMap  = new EnumMap<>(Day.class);

    for (Day day : Day.values()) {
      itemListMap.put(day, FXCollections.observableArrayList());
    }

    for (Item item : itemArrayList) {
      itemListMap.get(item.getDayOfWeek()).add(item);
    }

    ObjectProperty<Item> currentItem = new SimpleObjectProperty<>(null);

    List<String> categoryArrayList = new ArrayList<>();
    for (CategoryJson categoryJson : newJournal.categoryList()) {
      categoryArrayList.add(categoryJson.category());
    }

    ObservableList<String> categoryList = FXCollections.observableArrayList(categoryArrayList);
    ObservableList<Item> itemList = FXCollections.observableArrayList(itemArrayList);


    DataModel dataModel = new DataModel(itemList, itemListMap, currentItem, categoryList,
        newJournal.maxTasksPerDay(), newJournal.maxEventsPerDay(), newJournal.notes());

    System.out.println(dataModel.getAllItems());
    System.out.println(dataModel.getMaxEventsPerDay());

    return dataModel;
  }
}
