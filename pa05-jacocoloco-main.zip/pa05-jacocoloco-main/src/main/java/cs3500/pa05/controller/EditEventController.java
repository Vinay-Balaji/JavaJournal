package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.Event;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Popup;

/**
 * Represents a controller for editing an event.
 */
public class EditEventController {
  private final Popup popup;
  private final String resourcePath;
  private final DataModel model;

  @FXML
  private Button eventEditSubmit;

  @FXML private TextField eventEditTitle;

  @FXML private TextField eventEditStartTime;

  @FXML private TextField eventEditDuration;

  @FXML private ComboBox<String> eventEditCategory;

  @FXML private ChoiceBox<String> eventEditDay;

  @FXML private TextArea eventEditDescription;

  @FXML private Label eventEditError;

  /**
   * Constructs an EditEventController with the specified data model, stage, popup, and resource
   * path.
   *
   * @param m - the data model
   * @param p - the popup for the view
   * @param path - the resource path for the FXML file
   */
  public EditEventController(DataModel m, Popup p, String path) {
    popup = p;
    resourcePath = path;
    model = m;
  }

  /**
   * Sets up the controller by loading the FXML layout, initializing the UI components, and
   * setting event handlers.
   */
  public void setup() {
    FXMLLoader loader = new FXMLLoader();
    loader.setLocation(getClass().getClassLoader().getResource(resourcePath));
    loader.setController(this);
    try {
      Parent parent = ((Scene) loader.load()).getRoot();
      popup.getContent().add(parent);
      popup.setOpacity(1.0);
    } catch (IOException e) {
      throw new RuntimeException("Could not load resource");
    }

    eventEditSubmit.setOnAction(e -> handleSubmit());


    eventEditDay.getItems()
        .addAll("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    eventEditCategory.setItems(model.getCategoryList());
    eventEditCategory.getSelectionModel().select("No category");
    eventEditCategory.setValue("No category");
  }

  /**
   * Initializes the fields in the UI with the values of the current event.
   */
  public void initFields() {
    Event event = (Event) this.model.getCurrentItem();

    eventEditDay.setValue(event.getDayOfWeek().toString());
    eventEditTitle.setText(event.getTitle());
    eventEditStartTime.setText(event.getStartTime());
    eventEditDuration.setText(event.getDuration());
    eventEditDescription.setText(event.getDescription());
    eventEditCategory.setValue(event.getCategory());
  }

  /**
   * Handles the submit button action.
   */
  public void handleSubmit() {
    try {
      String title = eventEditTitle.getText();
      String category = eventEditCategory.getValue();


      Pattern pattern = Pattern.compile("#(\\S+?)(\\p{Z}|.$)");
      Matcher matcher = pattern.matcher(title);
      while (matcher.find()) {
        String tag = matcher.group().substring(1);
        model.addCategory(tag);
        category = tag;
        title = matcher.replaceFirst("");
      }

      Event toAdd = new Event(title,
          eventEditDay.getValue(),
          eventEditStartTime.getText(),
          eventEditDuration.getText(),
          eventEditDescription.getText(),
          category);

      this.model.replaceItem(this.model.getCurrentItem(), toAdd);

      // add category to list of category if new category
      model.addCategory(eventEditCategory.getValue());

      // Clear the form
      popup.hide();
      eventEditDay.setValue(null);
      eventEditTitle.clear();
      eventEditStartTime.clear();
      eventEditDuration.clear();
      eventEditDescription.clear();
      eventEditCategory.setValue("No category");
      eventEditError.setText("");

      // clear selected
      model.currentItemProperty().set(null);
    } catch (IllegalArgumentException e) {
      eventEditError.setText(e.getMessage());
    }
  }
}
