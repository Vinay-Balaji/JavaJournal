package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.Day;
import cs3500.pa05.model.Item;
import cs3500.pa05.model.Task;
import java.util.EnumMap;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Popup;
import javafx.stage.Stage;


/**
 * The JournalControllerImpl class is the controller for the journal application.
 * It handles user interactions and updates the associated data model accordingly.
 */
public class JournalControllerImpl {

  private final DataModel model;

  @FXML
  private Button saveToFile;

  @FXML
  private Button openFile;

  @FXML
  private Button createEvent;

  @FXML
  private Button createTask;

  @FXML
  private Button deleteButton;

  @FXML
  private Button editButton;

  @FXML
  private Button eventPromptSubmit;

  @FXML
  private Button setMax;

  @FXML
  private HBox dayBoxes;

  @FXML
  private TableView<Item> taskQueue;

  @FXML
  private TableColumn<Item, String> taskColumn;

  @FXML
  private TableColumn<Item, Boolean> statusColumn;

  @FXML
  private TextArea notes;

  private final Popup editEventPopup = new Popup();
  private final Popup editTaskPopup = new Popup();
  private final Popup eventPopup = new Popup();
  private final Popup taskPopup = new Popup();
  private final Popup maxTaskEventPopup = new Popup();
  private final Popup openFilePopup = new Popup();
  private final Popup saveFilePopup = new Popup();

  private final Stage stage;

  private EditEventController editEventController;

  private EditTaskController editTaskController;

  EnumMap<Day, ListView<Item>> dayListViews = new EnumMap<>(Day.class);

  /**
   * Constructs a new JournalControllerImpl with the specified stage.
   *
   * @param stage - The JavaFX stage associated with the controller.
   */
  public JournalControllerImpl(Stage stage) {
    this.model = new DataModel();
    this.stage = stage;
  }

  /**
   * Initializes the controller after the FXML components have been loaded and injected.
   * Sets up event handlers and initializes the view.
   */
  public void initialize() {
    EventPopupController eventPopupController =
        new EventPopupController(model, eventPopup, "EventPrompt.fxml");
    eventPopupController.setup();

    TaskPopupController taskPopupController =
        new TaskPopupController(model, taskPopup, "TaskPrompt.fxml");
    taskPopupController.setup();

    SetMaxTaskEventController setMaxTaskEventController =
        new SetMaxTaskEventController(
            model, maxTaskEventPopup, "maxTasks.fxml");
    setMaxTaskEventController.setup();

    OpenFileController openFileController =
        new OpenFileController(model, openFilePopup, "OpenFilePrompt.fxml", notes);
    openFileController.setup();

    SaveFileController saveFileController =
        new SaveFileController(model, saveFilePopup, "SaveFilePrompt.fxml");
    saveFileController.setup();

    EditEventController editEventController =
        new EditEventController(model, editEventPopup, "EditEventPrompt.fxml");
    editEventController.setup();
    this.editEventController = editEventController;

    EditTaskController editTaskController =
        new EditTaskController(model, editTaskPopup, "EditTaskPrompt.fxml");
    editTaskController.setup();
    this.editTaskController = editTaskController;

    // event/task creation buttons
    this.createEvent.setOnAction(new PopupHandler(stage, eventPopup));
    this.createTask.setOnAction(new PopupHandler(stage, taskPopup));

    // max events/tasks button
    this.setMax.setOnAction(new PopupHandler(stage, maxTaskEventPopup));

    // load/save buttons
    this.openFile.setOnAction(new PopupHandler(stage, openFilePopup));
    this.saveToFile.setOnAction(new PopupHandler(stage, saveFilePopup));

    // edit button
    this.editButton.setOnAction(this::handleEdit);

    // delete functionality
    this.deleteButton.setOnAction(this::handleDelete);


    // listview stuff (week view initialize
    initializeWeek();

    // tableview stuff
    initializeTaskQueue();

    // set model notes to text in notes box
    notes.setOnKeyTyped(event -> {
      model.setNotes(notes.getText());
      System.out.println(model.getNotes());
    });
  }

  /**
   * Initializes the week view in the UI.
   */
  public void initializeWeek() {
    for (Day day : Day.values()) {
      VBox dayBox = new VBox();
      dayBox.setPrefHeight(750);
      dayBox.setAlignment(Pos.TOP_CENTER);
      dayBoxes.getChildren().add(dayBox);
      Label dayLabel = new Label(day.toString());
      dayLabel.setFont(new Font("Gill Sans MT", 18));
      dayBox.getChildren().add(dayLabel);
      ListView<Item> dayList = new ListView<>(model.getDayItemList(day));
      dayList.setPrefHeight(750);
      dayBox.getChildren().add(dayList);
      dayListViews.put(day, dayList);
      dayList.setOnMouseClicked(event ->
          model.setCurrentItem(dayList.getSelectionModel().getSelectedItem())
      );
    }
  }

  /**
   * Initializes the task queue view in the UI.
   */
  public void initializeTaskQueue() {
    taskQueue.setEditable(true);
    taskColumn.setCellValueFactory(data -> data.getValue().titleProperty());
    taskColumn.setEditable(false);
    statusColumn.setCellValueFactory(data -> ((Task) data.getValue()).completeProperty());
    statusColumn.setCellFactory(column -> new CheckBoxTableCell<>());
    statusColumn.setEditable(true);

    taskQueue.setOnMouseClicked(event ->
        model.setCurrentItem(taskQueue.getSelectionModel().getSelectedItem())
    );
    taskQueue.setItems(new FilteredList<>(model.getAllItems(), s -> s instanceof Task));
  }

  /**
   * Handles the "Edit" button click event.
   *
   * @param e - The event triggered by the "Edit" button.
   */
  public void handleEdit(ActionEvent e) {
    if (model.getCurrentItem() instanceof cs3500.pa05.model.Event) {
      new PopupHandler(stage, editEventPopup, this.editEventController).handle(e);
    } else if (model.getCurrentItem() instanceof cs3500.pa05.model.Task) {
      new PopupHandler(stage, editTaskPopup, editTaskController).handle(e);
    }
  }

  /**
   * Handle "Delete" button click event
   *
   * @param e Event from clicking delete button
   */
  public void handleDelete(Event e) {
    Item item = model.getCurrentItem();
    if (item != null) {
      model.removeItem(item);
    }
  }

}


