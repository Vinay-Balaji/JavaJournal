package cs3500.pa05.controller;

/**
 * The JournalController interface represents a controller for a journal application.
 */
public interface JournalController {
  /**
   * Sets up the journal controller by performing necessary initialization tasks.
   */
  public void setup();

  /**
   * Runs the journal application, allowing it to handle user interactions and perform actions.
   */
  public void run();

  /**
   * Ends the journal application, performing any cleanup or finalization tasks.
   */
  public void end();

}
