package cs3500.pa05.controller;

import cs3500.pa05.model.DataModel;
import cs3500.pa05.model.FileWorker;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Popup;


/**
 * Class to control popup created by open file button
 */
public class OpenFileController {
  private final Popup popup;
  private final String resourcePath;
  private final DataModel model;

  @FXML
  private TextField filePromptInput;

  @FXML
  private Label filePromptError;

  @FXML
  private Button filePromptSubmit;

  private final TextArea notes;

  /**
   * Constructor to create a controller
   *
   * @param model injected data model for whole app
   * @param p popup javafx object
   * @param path path to fxml popup
   * @param notes injected javafx notes from main window, to update upon loading new file
   */
  public OpenFileController(DataModel model, Popup p, String path, TextArea notes) {
    popup = p;
    resourcePath = path;
    this.model = model;
    this.notes = notes;
  }

  /**
   * Setup method for open file popup
   */
  public void setup() {
    FXMLLoader loader = new FXMLLoader();
    loader.setLocation(getClass().getClassLoader().getResource(resourcePath));
    loader.setController(this);
    try {
      Parent parent = ((Scene) loader.load()).getRoot();
      popup.getContent().add(parent);
      popup.setOpacity(1.0);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }

    filePromptSubmit.setOnAction(e -> handleSubmit());
  }

  /**
   * Method invoked upon hitting submit button in popup
   */
  public void handleSubmit() {
    DataModel fromFile;
    String filePath = filePromptInput.getText().trim();
    try {
      fromFile = FileWorker.handleLoadFromFile(filePath);
      model.updateModel(fromFile);
      notes.setText(model.getNotes());
      filePromptError.setText("");
      popup.hide();
      filePromptInput.clear();
    } catch (IllegalArgumentException e) {
      filePromptError.setText(e.getMessage());
    }
  }
}
